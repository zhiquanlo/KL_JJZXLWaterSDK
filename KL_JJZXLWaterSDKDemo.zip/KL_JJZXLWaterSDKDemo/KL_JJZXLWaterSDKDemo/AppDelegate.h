//
//  AppDelegate.h
//  KL_JJZXLWaterSDKDemo
//
//  Created by 李志权 on 2020/7/13.
//  Copyright © 2020 kailu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong,nonatomic)UIWindow *window;
@end

